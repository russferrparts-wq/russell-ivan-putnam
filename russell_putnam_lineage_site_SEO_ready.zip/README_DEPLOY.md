# Russell Ivan Putnam — Historical Lineage Archive (Deployment Guide)

This folder is a static website (no server required). It is ready to publish on GitHub Pages.

## 1) View locally (right now)
- Open `index.html` in any browser.

## 2) Publish on GitHub Pages (free)
1. Create a GitHub account (if you don't have one).
2. Create a NEW repository named: `russell-ivan-putnam` (Public).
3. Upload ALL files from this folder (keep the same structure), then "Commit changes".
4. In the repo, go to **Settings → Pages**:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
   - Save
5. Your site will be live at:
   `https://YOURGITHUBUSERNAME.github.io/russell-ivan-putnam/`

## 3) IMPORTANT: Update placeholders for Google indexing
This site includes `sitemap.xml` and `robots.txt`, but they include a placeholder URL.

After you know your final site URL, open these files and replace:
`https://YOURDOMAIN_OR_GITHUBPAGES_URL`
with your real site URL, for example:
- GitHub Pages: `https://YOURGITHUBUSERNAME.github.io/russell-ivan-putnam`
- Custom domain: `https://russellivanputnam.org`

Files to update:
- `robots.txt`
- `sitemap.xml`
- (Optional) the `canonical` URLs in each HTML file still point to the placeholder. You can ignore this until you set a final URL.

## 4) Submit to Google (Search Console)
1. Go to Google Search Console: https://search.google.com/search-console
2. Add property → "URL prefix" → paste your site URL
3. Verify ownership (Google will guide you)
4. Use **URL Inspection** → "Request indexing"

## 5) Optional: Custom domain (recommended)
Buy a domain from any registrar (Namecheap/Google Domains replacement/Cloudflare).
Then in GitHub Pages settings add the domain under "Custom domain" and follow the DNS instructions.

---
If you want, share your GitHub username + the domain you want, and I can give you exact copy/paste values for the final URLs/DNS.
