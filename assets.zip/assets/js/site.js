
async function loadIndex(){
  const res = await fetch('archive_index.json');
  return await res.json();
}

function el(tag, attrs={}, children=[]){
  const node=document.createElement(tag);
  for(const [k,v] of Object.entries(attrs)){
    if(k==='class') node.className=v;
    else if(k==='html') node.innerHTML=v;
    else node.setAttribute(k,v);
  }
  for(const c of children) node.appendChild(c);
  return node;
}

function normalize(s){ return (s||'').toLowerCase(); }

async function initArchive(){
  const data = await loadIndex();
  const entries = data.entries || [];
  const q = document.getElementById('q');
  const cat = document.getElementById('cat');
  const list = document.getElementById('list');
  const count = document.getElementById('count');

  // build category dropdown options
  const cats = Array.from(new Set(entries.map(e => e.category).filter(Boolean))).sort();
  for(const c of cats){
    cat.appendChild(el('option',{value:c, html:c}));
  }

  function render(){
    const qv = normalize(q.value);
    const cv = cat.value;
    const filtered = entries.filter(e=>{
      const blob = normalize([e.title, e.summary, e.relevance, (e.people||[]).join(' '), e.place, e.source, e.type, e.category, e.id].join(' '));
      const matchQ = !qv || blob.includes(qv);
      const matchC = !cv || e.category === cv;
      return matchQ && matchC;
    });

    count.textContent = `${filtered.length} document(s)`;
    list.innerHTML = '';
    for(const e of filtered){
      const title = e.title || e.id;
      const meta = [e.date, e.type, e.category].filter(Boolean).join(' • ');
      const card = el('div',{class:'card'});
      const img = el('img',{class:'thumb',src:e.filename,alt:title,loading:'lazy'});
      const h = el('h3',{html:title});
      h.style.margin='10px 0 6px';
      h.style.fontSize='16px';
      const m = el('div',{class:'small', html: meta || '—'});
      const s = el('p',{class:'muted', html: e.summary || ''});
      const a = el('a',{class:'btn secondary', href:e.filename, target:'_blank', rel:'noopener', html:'Open image'});
      a.style.marginTop='8px';
      card.appendChild(img);
      card.appendChild(h);
      card.appendChild(m);
      if(e.summary) card.appendChild(s);
      card.appendChild(a);
      list.appendChild(card);
    }
  }

  q.addEventListener('input', render);
  cat.addEventListener('change', render);
  render();
}

document.addEventListener('DOMContentLoaded', ()=>{
  if(document.getElementById('archive-page')) initArchive();
});
